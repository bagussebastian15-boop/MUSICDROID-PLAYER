# Media3 dan Compose membawa aturan consumer sendiri; tidak ada aturan tambahan.
